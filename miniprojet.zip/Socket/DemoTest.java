package com.example.demo.test;

public class DemoTest {
    public static void main(String[] args) {
        String clientStr = "555!333";
        String est = splitStr(clientStr);
        if (est.length() != 1) {
            System.out.println(est);
            return;
        }

        System.out.println("Integer_1= " + Integer.valueOf(clientStr.substring(0, clientStr.indexOf(est))));
        System.out.println("est= " + est);
        System.out.println("Integer_2= " + clientStr.substring(clientStr.indexOf(est) + 1));
    }

    private static String splitStr(String s) {
        String[] strings = new String[4];
        strings[0] = "+";
        strings[1] = "-";
        strings[2] = "*";
        strings[3] = "/";

        String s1 = null;

        for (String str : strings) {
            boolean contains = s.contains(str);
            if (contains) {
                s1 = str;
                break;
            }
        }

        if (s1 == null) {
            return "不支持的运算方式！";
        } else {
            return s1;
        }
    }
}

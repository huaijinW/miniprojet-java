package calculatrice;

import java.io.*;
import java.net.*;
import java.util.*;

public class Client {
    public static void main(String[] zero) {    

		Socket socket2;
        
        try {
			socket2 = new Socket(InetAddress.getLocalHost(),2009);
			BufferedReader in = new BufferedReader (new InputStreamReader (socket2.getInputStream()));
			PrintWriter out = new PrintWriter(socket2.getOutputStream());
			Scanner sc = new Scanner(System.in); 

            System.out.println("Demande de connexion");
            String message_distant = in.readLine();
            System.out.println(message_distant);
            
			String str = sc.nextLine(); 
			out.println(str);
			out.flush();
			//String resultat = in.readLine();
			int res = Integer.parseInt(in.readLine());//on transfert le message de string à l'entier
			while ((res == -1) || (res == -2)) {
				if (res == -1) { //Erreur d'entre
					System.out.println("Veuillez saisir les valeurs positives!!!");}
				else if (res == -2) { //Erreur de sortie
					System.out.println("Resultat incorrect!!!");
				}
				System.out.println("Entrez une nouvelle formule");
				str = sc.nextLine();  //on renvoie une nouvelle formule
				out.println(str);
				out.flush();
				res = Integer.parseInt(in.readLine()); //on obtient un nouveau res
			}
			
			String resultat = str + " = " + res;
            System.out.println(resultat);
            socket2.close();    
        }catch (UnknownHostException e) {         	
            e.printStackTrace();         
        }catch (IOException e) {
        	e.printStackTrace();
        }
    }
}

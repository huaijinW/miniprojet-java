package calculatrice;

import java.io.*;
import java.net.*;
import java.util.*;


class Accepter_clients implements Runnable {
	
	private ServerSocket socketserver;
	private Socket socket1;
	BufferedReader in;
	PrintWriter out;
	private int nbrclient = 1;
	public Accepter_clients(ServerSocket s){
		socketserver = s;
	}

	public void run() {
		try {
			while(true){

				socket1 = socketserver.accept(); // Un client se connecte on l'accepte
				System.out.println("Le client numero "+nbrclient+ " est connecte !");
				nbrclient++;

				out = new PrintWriter(socket1.getOutputStream());
				out.println("Saisir une operation !");
				out.flush();
            
				in = new BufferedReader (new InputStreamReader (socket1.getInputStream()));
				int res = -1;
				while (res < 0) {
					String message_distant = in.readLine();
					System.out.println(message_distant);
					String[] operation = message_distant.split(" ");//On separe le string en utilisant la methode split97
				
					int i1 = Integer.valueOf(operation[0]);
					int i2 = Integer.valueOf(operation[2]);
					String operateur = operation[1];
				
					//System.out.println("Integer_1= " + i1);
					//System.out.println("operateur est " + operateur);
					//System.out.println("Integer_2= " + i2);
				
					if ((i1 < 0) || (i2 < 0)) { //Si la valeur d'entree est negative, on retournre -1
						res = -1;
						out.println(res);
						out.flush();
					}
					else {
						int r = 0;
						switch (operateur){
							case "+":r = i1 + i2;break;
							case "-":r = i1 - i2;break;
							case "*":r = i1 * i2;break;
							case "/":
								if (i2 != 0){r = i1 / i2;}
								else {r = -1;} //si le diviseur est zero
								break;
						}

						if (r < 0) { //si le resultat est negative
							res = -2;
							out.println(res);
							out.flush();}
						else { //si il n'y a pas d'erreur, on retourne la valeur obtenue
							res = r;
							out.println(res);
							out.flush();}
					}
				//socket1.close();
			}           
		}} catch (IOException e) {

			e.printStackTrace();
		}
	}
}

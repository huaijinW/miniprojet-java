import java.util.*;
import java.io.*;

public class Test
{
	public static void main (String[] args) 
	{
		List<Tableau> tab = new ArrayList<Tableau>();
		List<P1> p1 = new ArrayList<P1>();
		List<P2> p2 = new ArrayList<P2>();
		List<P3> p3 = new ArrayList<P3>();
		
		Scanner sc = new Scanner(System.in); 
		System.out.println("Saisir le nombre de Threads");
		int n = sc.nextInt();
		System.out.println("nombre de Threads:"+n); 
		
		
		//int n = 3;
		
		for (int i=0; i<n; i++){
			System.out.println("Saisir la dimension de Tableau "+(i+1));
			int dim = sc.nextInt();
			System.out.println("La dimension de ce tableau est "+dim);
			tab.add(new Tableau(dim,i));
		}
		
		
		for (int i=0; i<n; i++) {
            p1.add(new P1(tab.get(i)));
            p2.add(new P2(tab.get(i)));
            p3.add(new P3(tab.get(i)));
		}
		
		for (int i=0; i<n; i++){
            p1.get(i).start();
            p2.get(i).start();
            p3.get(i).start();
        }
		
		/*Tableau t = new Tableau (n);
		P1 a = new P1 (t);
		P2 b = new P2 (t);
		P3 c = new P3 (t);
		a.start();
		b.start();
		c.start();
		try 
		 {
			 a.join(); 
			 b.join();
			 c.join();
		 }
		 catch (Exception ex) {}*/
		 
		 for (int i=0; i<n; i++) {
			try {
				p1.get(i).join();
				p2.get(i).join();
				p3.get(i).join();
			} 
			catch (Exception ex) {}
		}

		 System.out.println ("end ");
			}
}

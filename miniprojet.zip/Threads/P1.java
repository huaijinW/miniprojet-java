public class P1 extends Thread{

	private Tableau t;
	
	public P1 (Tableau t) { this.t = t;}
	
	public void run() {
	
		try{
			for (int i=0; i<t.getDim(); i++)
				synchronized ( this.t ) {
					while (this.t.estRempli(i)) {this.t.wait();}
					t.setData(i,1+10*(float)Math.random());  //la valeur de tableau est entre 1 et 11
					//System.out.println(t.getData(i));
					this.t.notifyAll();
				}
		}
		catch (Exception e) {}
	}
	
}

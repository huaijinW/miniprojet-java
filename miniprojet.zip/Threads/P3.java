public class P3 extends Thread {
	
	private Tableau t;
	
	public P3 (Tableau t){ this.t = t;}
	
	public void run(){
		try{
			for (int i=0; i<t.getDim(); i++)
			synchronized ( this.t ){
				while (this.t.estAffiche(i)) {this.t.wait();}
				this.sleep(1000);
				System.out.println("la "+(i+1)+"-ieme valeur de tableau "+(t.getIndice()+1)+": "+t.getData(i));//on affiche la valeur dans le terminal
				this.t.notifyAll();
			}
		}
		catch (Exception e) {}
	}
}

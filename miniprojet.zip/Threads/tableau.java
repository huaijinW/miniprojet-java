public class Tableau{
	
	private float[] t;
	private int dim;
	private int k;
	private int l;
	
	public Tableau (int dim, int l){
		this.dim = dim;
		this.t = new float[dim];
		this.k = 0;
		this.l = l;
	}
	
	public int getDim () {return this.dim;} //pour obtenir la dimension de tableau
	
	public float getData (int i) {return this.t[i];} //pour obtenir l'élément dans la i-ème situation du tableau
	
	public void setData (int i, float x) {this.t[i] = x;} //pour enregistrer la valeur x dans la situation i
	
	public int getIndice () {return this.l;};
	
	public synchronized float addition(int i) {return (this.t[i] + 1);} //on change la valeur de tableau par plus 1
	
	public boolean estRempli (int i) {return (this.t[i] != 0);} //pour vérifier si cette situation est remplie
	
	public boolean estTransfere (int i) {return (this.t[i] == 0);} //pour vérifier si la valeur est transférée
	
	public boolean estAffiche (int i) {return this.k == i;} //pour vérifier si la valeur est affichée dans le terminal
	
	public synchronized void boucle()
	{ 	this.k++; 	} //chaque fois une valeur est transféré, k plus 1
	
	//public String toString() {}
	
}

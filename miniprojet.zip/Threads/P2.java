public class P2 extends Thread{
	
	private Tableau t;
	
	public P2 (Tableau t) { 
		this.t = t;
	}
	
	public void run () 
	{
		try{
			for (int i=0; i<t.getDim(); i++)
				synchronized ( this.t ) {
					while (this.t.estTransfere(i)) {this.t.wait();}
					this.sleep(1000);
					this.t.setData(i,this.t.addition(i));//On transfère 
					//la valeur et remplit la nouvelle valeur dans le tableau
					this.t.boucle();//Chaque fois la valeur est transféré, k + 1
					this.t.notifyAll();
				}
		}
		catch (Exception e) {}
	}
}

import java.io.Serializable;
import serviceDeChiffrement.*;
import java.rmi.RemoteException;

public class EncrypteImpl implements Encrypte {

	public String encrypteInt(int parametre) throws RemoteException{
		return ("Message encrypted : " + (parametre + 1));
	}
	
	public String encrypteDocument(Document d) throws RemoteException{		
		return ("Document encrypted : " + d.getContenu() + " est crypte !");
	}
	
	public void encrypteFichier(Fichier nomDuFichier) throws RemoteException{
		String contenu = nomDuFichier.getContenu();
		nomDuFichier.setContenu(contenu + " est crypte !");
	}
}

import java.io.Serializable;
import java.io.*;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Fichier extends Remote{
   public String getContenu() throws RemoteException;
   public void setContenu(String nouveauContenu) throws RemoteException;
}

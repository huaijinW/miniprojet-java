import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.io.*;
import serviceDeChiffrement.*;
import java.io.Serializable;

public class Client {
	public static void main(String args[]) {
    String machine = "localhost";
    int port = 1099;
    int quitter = -1; 
    try {
		Registry registry = LocateRegistry.getRegistry(machine, port);
		Encrypte obj = (Encrypte)registry.lookup("EncrypteSerializable");
		while (quitter != 0) {
			System.out.println("Integer = 1");
			System.out.println("Document = 2");
			System.out.println("Fichier = 3");
			System.out.println("Quelle type vous voulez encryter ?");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int i = Integer.parseInt(br.readLine());
			
			if (i == 1) {
				System.out.println("Entrez un parametre");
				System.out.println(obj.encrypteInt(Integer.parseInt(br.readLine())));
			}
			else if (i == 2) {
				System.out.println("Entrez un Document");
				System.out.println(obj.encrypteDocument(new Document(br.readLine())));
			}
			else if (i == 3) {
				System.out.println("Entrez le nom du fichier");
				Fichier stubFichier, aFichier = new FichierImpl(br.readLine());
				stubFichier = (Fichier)UnicastRemoteObject.exportObject(aFichier,0);
				obj.encrypteFichier(stubFichier);
				UnicastRemoteObject.unexportObject(aFichier, true);
			} 
			System.out.println("Si vous voulez le quitter, tapez 0");
			quitter = Integer.parseInt(br.readLine());
		}
	}catch (Exception e) {
			System.out.println("Client exception: " +e);
	}
	}
}

import java.awt.*;
import javax.swing.*;

public class EssaiGridLayout extends JPanel
{
	private JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16;
	//public static final int WIDTH = 600;
	//public static final int HEIGHT = 800;
	public EssaiGridLayout()
	{
		this.setLayout(new  GridLayout( 4 , 4 ) );
		this.setPreferredSize(new Dimension(600,800));
		b1 = new JButton ("7"); b2 = new JButton ("8"); b3 = new JButton ("9"); b4 = new JButton ("+");
		b5 = new JButton ("4"); b6 = new JButton ("5"); b7 = new JButton ("6"); b8 = new JButton ("-");
		b9 = new JButton ("1"); b10 = new JButton ("2"); b11 = new JButton ("3"); b12 = new JButton ("*");
		b13 = new JButton ("supp"); b14 = new JButton ("0"); b15 = new JButton ("="); b16 = new JButton ("/");
		b15.setBackground(Color.red);
		this.add (b1); this.add (b2); this.add (b3); this.add (b4);
		this.add (b5); this.add (b6); this.add (b7); this.add (b8); 
		this.add (b9); this.add (b10); this.add (b11); this.add (b12);
		this.add (b13); this.add (b14); this.add (b15); this.add (b16);
		this.setVisible(true);
	}
}


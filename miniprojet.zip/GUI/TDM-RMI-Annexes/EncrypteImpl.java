import java.io.*;
import serviceDeChiffrement.*;
import java.rmi.RemoteException;


public class EncrypteImpl implements Encrypte {

	
	
	public int encrypteDocument(String d) throws RemoteException{		
	
		int res = -4;
		String[] operation = d.split(" ");//On separe le string en utilisant la methode split
		if (operation.length == 3){
			try {
				int i1 = Integer.parseInt(operation[0]);
				int i2 = Integer.parseInt(operation[2]);
				char operateur = operation[1].charAt(0);
				System.out.println(res);
				if ((i1 < 0) || (i2 < 0)) { //Si la valeur d'entree est negative, on retournre -1
					res = -1;
				}
				else {
					System.out.println(res);
					switch (operateur){
						case '+':res = i1 + i2;break;
						case '-':{
							if (i1 - i2 < 0) {res = -2;System.out.println(res);}
							else {res = i1 - i2;}
							break;}
						case '*':res = i1 * i2;break;
						case '/':{
							if (i2 != 0){res = i1 / i2;System.out.println("division par 0");}
							else {res = -3;} //si le diviseur est zero
							break;}
					}
				}
			} catch (Exception e) {
				System.out.println("calcul invalid");
			}
		} 
		return res;
	}

}

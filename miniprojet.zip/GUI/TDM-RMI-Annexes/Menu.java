import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Menu extends JMenuBar
{
	public Menu()
	{
		JTextField t = new JTextField();
		ActionListener quitter = new ActionListener()
		{
			public void actionPerformed (ActionEvent event)
			{
				System.exit(0);
			}
		};
		/*ActionListener nouveau = new ActionListener() 
		{
			public void actionPerformed (ActionEvent event)
			{
				t.setText("");
			}
		};*/
		JMenu fichierMenu = new JMenu("MENU"); 
		JMenuItem /*item = new JMenuItem ("New", 'n'); 
		item.addActionListener(nouveau); 	fichierMenu.add(item);
		fichierMenu.addSeparator();*/
		item = new JMenuItem("Quit");
		item.addActionListener(quitter); 	fichierMenu.add (item);
		this.add(fichierMenu);
	}
	
}


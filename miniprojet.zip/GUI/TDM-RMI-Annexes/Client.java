import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.io.*;
import serviceDeChiffrement.*;
import java.io.Serializable;

public class Client {
	public static void main(String args[]) {
		GridCalculatrice frame = new GridCalculatrice();

	}
}

import java.rmi.Remote;
import java.rmi.RemoteException;
import serviceDeChiffrement.*;

public interface Encrypte extends Remote {
	//public String encrypteInt(int parametre) throws RemoteException;
	public int encrypteDocument(String d) throws RemoteException;
	//public void encrypteFichier(Fichier nomDuFichier) throws RemoteException;
}

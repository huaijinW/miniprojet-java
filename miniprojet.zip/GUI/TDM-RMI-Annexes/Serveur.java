import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Arrays;

public class Serveur {
	public static void main(String args[]) {
		int port  = 1099;
		try {
			Encrypte skeleton = (Encrypte)UnicastRemoteObject.exportObject(new EncrypteImpl(), 0);
			Registry registry = LocateRegistry.getRegistry(port);
			
			
			if(!Arrays.asList(registry.list()).contains("EncrypteSerializable")) {
				registry.bind("EncrypteSerializable", skeleton);
			}
			else {
				registry.rebind("EncrypteSerializable", skeleton);

			}
			  System.out.println("Service EncrypteSerializable lie au registre");
			} catch (Exception e) {
			  System.out.println(e);
			}
			
		
	}
}

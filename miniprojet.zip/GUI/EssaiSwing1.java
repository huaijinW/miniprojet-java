import javax.swing.*;
import java.awt.*;

public class EssaiSwing1 
{
	
	public static void main (String[] args)
	{
		JFrame cal = new JFrame("Calculatrice");
		JPanel panneau = new JPanel();
		EssaiGridLayout f = new EssaiGridLayout();
		panneau.add(f);
		cal.setSize(700,900);
		cal.add(panneau);
		cal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cal.setVisible(true);
	}
}

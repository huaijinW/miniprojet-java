import java.rmi.Remote;
import java.rmi.RemoteException;
import serviceDeChiffrement.*;

public interface Encrypte extends Remote {
	
	public int encrypteDocument(String d) throws RemoteException;
	
}

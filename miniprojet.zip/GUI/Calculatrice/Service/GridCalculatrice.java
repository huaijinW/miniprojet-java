import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class GridCalculatrice extends JFrame
{		private JFrame cal;
		private JTextField t; 
		private JPanel panneau; 
		private boolean nouveauCalcul;
	
	
	public GridCalculatrice() {
		nouveauCalcul = true;
		cal = new JFrame("Calculatrice");
		cal.setSize(700,900);
		
		Menu menu = new Menu();
		cal.setJMenuBar(menu);
		
		t = new JTextField();
		t.setPreferredSize(new Dimension(700,120));
		t.setText("");
		
		panneau = new JPanel();
		panneau.add(t);
		
		JPanel b = new JPanel();
		b.setPreferredSize(new Dimension(600,800));
		b.setLayout(new GridLayout(4, 4));
		
		JButton b1 = new JButton ("7"); 
		JButton b2 = new JButton ("8"); 
		JButton b3 = new JButton ("9"); 
		JButton b4 = new JButton ("+");
		JButton b5 = new JButton ("4"); 
		JButton b6 = new JButton ("5"); 
		JButton b7 = new JButton ("6"); 
		JButton b8 = new JButton ("-");
		JButton b9 = new JButton ("1"); 
		JButton b10 = new JButton ("2"); 
		JButton b11 = new JButton ("3"); 
		JButton b12 = new JButton ("*");
		JButton b13 = new JButton ("supp"); 
		JButton b14 = new JButton ("0"); 
		JButton b15 = new JButton ("=");
		JButton b16 = new JButton ("/");
		
		b15.setBackground(Color.red);
		
		b.add (b1); b.add (b2); b.add (b3); b.add (b4);
		b.add (b5); b.add (b6); b.add (b7); b.add (b8); 
		b.add (b9); b.add (b10); b.add (b11); b.add (b12);
		b.add (b13); b.add (b14); b.add (b15); b.add (b16);
		
		cal.getContentPane().add(panneau, BorderLayout.NORTH);
		cal.getContentPane().add(b, BorderLayout.CENTER);
		cal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cal.setVisible(true);
		
		b1.addActionListener(afficherValeur);
		b2.addActionListener(afficherValeur);
		b3.addActionListener(afficherValeur);
		b4.addActionListener(afficherOperateur);
		b5.addActionListener(afficherValeur);
		b6.addActionListener(afficherValeur);
		b7.addActionListener(afficherValeur);
		b8.addActionListener(afficherOperateur);
		b9.addActionListener(afficherValeur);
		b10.addActionListener(afficherValeur);
		b11.addActionListener(afficherValeur);
		b12.addActionListener(afficherOperateur);
		b13.addActionListener(effacer);
		b14.addActionListener(afficherValeur);
		b15.addActionListener(Calculer);
		b16.addActionListener(afficherOperateur);
		
	}
	
	ActionListener afficherValeur = new ActionListener()
	{
		public void actionPerformed (ActionEvent e)
		{	
			if (nouveauCalcul) {
				t.setText("");
				nouveauCalcul = false;
			}
			t.setText(t.getText() + e.getActionCommand());
		} 
	};
		
	ActionListener afficherOperateur = new ActionListener()
	{
		public void actionPerformed (ActionEvent e)
		{
			if (nouveauCalcul) {
				t.setText("");
				nouveauCalcul = false;
			}
			t.setText(t.getText() + " " + e.getActionCommand() + " ");
		} 
	};
		
	ActionListener Calculer = new ActionListener()
	{
		public void actionPerformed (ActionEvent e)
		{
			String machine = "localhost";
			int port = 1099;
			try {
				Registry registry = LocateRegistry.getRegistry(machine, port);
				Encrypte obj = (Encrypte)registry.lookup("EncrypteSerializable");

				int res = obj.encrypteDocument(t.getText());
					
				if (res == -1) { 
					t.setText("Veuillez saisir les valeurs positives!!!");}
				else if (res == -2) { 
					t.setText("Resultat negatif!!!");}
				else if (res == -3) {
					t.setText("Math Error: la diviseur est nulle!!!");}
				else if (res == -4) {
					t.setText("Syntaxe Error: la formule illegale!!!");}
				else {
					t.setText(t.getText() + " = " + res);
					System.out.println(t.getText());
				}
				nouveauCalcul = true;
			}catch (Exception ex) {
					System.out.println("Client exception: " +ex);
			}
			
		} 
	};
	
	ActionListener effacer = new ActionListener()
	{
		public void actionPerformed (ActionEvent e)
		{
			String temp = t.getText();
			if (temp.length() != 0)  {
				t.setText(temp.substring(0, temp.length()-1));
			}
		} 
	};
	
	
	/*public static void main(String[] args) {
		GridCalculatrice frame = new GridCalculatrice();
		
	}*/
}


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Menu extends JMenuBar
{
	public Menu()
	{
		JTextField t = new JTextField();
		ActionListener quitter = new ActionListener()
		{
			public void actionPerformed (ActionEvent event)
			{
				System.exit(0);
			}
		};

		JMenu fichierMenu = new JMenu("MENU"); 
		JMenuItem item = new JMenuItem("Quit");
		item.addActionListener(quitter); 	
		fichierMenu.add (item);
		this.add(fichierMenu);
	}
	
}

